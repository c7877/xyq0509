var rule = {
    title: 'NyaFun',
    模板:'短视2',
    host: 'https://www.nyafun.net',
	url: '/index.php/api/vod#type=fyclass&page=fypage',
    class_name:'新旧番剧&剧场版&ASMR&番剧OP、ED',
    class_url:'2&1&103&104',
    detailUrl:'/bangumi/fyid.html',
}